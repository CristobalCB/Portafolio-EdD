package sistema.seguimiento.mantencion.modelo;

import java.time.LocalDate;
import java.time.Period;
import java.util.Iterator;
import java.util.TreeSet;

public class Lista {

    private TreeSet<Camion> camiones;
    private TreeSet<Bus> buses;
    private final LocalDate actual = LocalDate.now();

    /**
     * Constructor, llena las lista y cheques que cuando se creó el objeto lista los camiones y buses registrados no
     * excedan los 6 meses desde la ultima revisión.
     */
    public Lista(){
        camiones = new TreeSet<>();
        buses = new TreeSet<>();
        llenarlista();
        time();
    }

    /**
     * Agrega los km recorridos por un bus y verifica si se le ha hecho la revision por exceder los 15000km.
     * @param bus - Bus que realizó el bus.
     * @param km - kilometros recorridos durante el viaje
     */
    public void viaje(Bus bus, int km){
        bus.setKmActual(bus.getKmActual() + km);
        if (bus.getKmActual() > 15000 && bus.getKmMantencion() < 15000){
            bus.setMantencion(false);
            bus.setMotivoMantencion("Se ha excedido los 15000km.");
        }
    }

    /**
     * Agrega los km recorridos por un camión y verifica si se le ha hecho la revision por exceder los 15000km.
     * @param camion - Camión que realizó el camion.
     * @param km - kilometros recorridos durante el viaje
     */
    public void viaje(Camion camion, int km){
        camion.setKmActual(camion.getKmActual() + km);
        if (camion.getKmActual() > 15000 && camion.getKmMantencion() < 15000){
            camion.setMantencion(false);
            camion.setMotivoMantencion("Se ha excedido los 15000km.");
        }
    }

    /**
     * Revisa si los camiones y buses registrados tiene  mas de 6 meses sin revision desde la fecha actual.
     */
    private void time(){
        long period;
        for (Camion camion : camiones){
            period = Period.between(camion.getUltimaMantencion(),actual).toTotalMonths();
            if (period > 6){
                camion.setMantencion(false);
                camion.setMotivoMantencion("Última revisión hace 6 meses.");
            }
        }
        for (Bus bus : buses) {
            period = Period.between(bus.getUltimaMantencion(),actual).toTotalMonths();
            if (period > 6){
                bus.setMantencion(false);
                bus.setMotivoMantencion("Última revisión hace 6 meses.");
            }
        }
    }

    /**
     * Inicia los camiones y buses es sus correspondientes listas, se puede poner un lector de base de dato aqui en
     * lugar de esto.
     */
    private void llenarlista(){
        buses.add(new Bus("FN-YH-29","NMK898735",(byte) 2,"MERCEDES BENZ",
                LocalDate.of(2017,4,21),110000,4000,
                LocalDate.of(2020,7,21), TipoCarga.PASAJERO,"s1",true,
                "Sin necesidad de mantención",false));
        buses.add(new Bus("MH-ZP-18","PTG852853",(byte) 4,"MERCEDES BENZ",
                LocalDate.of(2016,12,21),85000,18000,
                LocalDate.of(2015,12,9), TipoCarga.ENCOMIENDA,"s1",true,
                "Sin necesidad de mantención",true));
        buses.add(new Bus("GD-LZ-21","KHJ667261",(byte) 2,"MERCEDES BENZ",
                LocalDate.of(2019,5,23),50000,47000,
                LocalDate.of(2013,12,19), TipoCarga.ENCOMIENDA,"s1",true,
                "Sin necesidad de mantención",true));
        buses.add(new Bus("LM-AS-32","MVB777254",(byte) 4,"SCANIA",
                LocalDate.of(2019,2,28),20000,15000,
                LocalDate.of(2015,12,19), TipoCarga.PASAJERO,"s1",true,
                "Sin necesidad de mantención",true));

        camiones.add(new Camion("HI-OO-99","AAJF44411",(byte) 2,"VOLVO",
                LocalDate.of(2015,3,4),35000,34000,
                LocalDate.of(2013,12,19),TipoCarga.ALIMENTO,"s1",
                true,"Sin necesidad de mantención"));
        camiones.add(new Camion("LM-WW-18","KDJ887441",(byte) 2,"VOLVO",
                LocalDate.of(2018,4,6),111000,23000,
                LocalDate.of(2013,12,19),TipoCarga.ALIMENTO,"s1",
                true,"Sin necesidad de mantención"));
        camiones.add(new Camion("WW-AZ-56","JJJ637344",(byte) 2,"SCANIA",
                LocalDate.of(2019,8,9),11000,5000,
                LocalDate.of(2020,7,19),TipoCarga.ALIMENTO,"s1",
                true,"Sin necesidad de mantención"));
        camiones.add(new Camion("TYD-EF-32","KDD662311",(byte) 2,"SCANIA",
                LocalDate.of(2013,3,1),211000,200000,
                LocalDate.of(2013,12,19),TipoCarga.ALIMENTO,"s1",
                true,"Sin necesidad de mantención"));

    }

    /**
     * Registra si se ha hecho la mentención
     * @param bus - Transporte el cual se registra su mantención.
     */
    public void mantenimiento(Bus bus){
        bus.mantencion();
    }

    /**
     * Registra si se ha hecho la mentención
     * @param camion - Transporte el cual se registra su mantención.
     */
    public void mantenimiento(Camion camion){
        camion.mantencion();
    }

    /**
     * Registra si ha surguido algo que haga que la mantencion ser requerida.
     * @param camion - Transporte el cual se registra el fallo.
     * @param motivo - Descripción del fallo.
     */
    public void falla(Camion camion, String motivo){
        camion.setMantencion(false);
        camion.setMotivoMantencion(motivo);

    }

    /**
     * Registra si ha surguido algo que haga que la mantencion ser requerida.
     * @param bus - Transporte el cual se registra el fallo.
     * @param motivo - Descripción del fallo.
     */
    public void falla(Bus bus, String motivo){
        bus.setMantencion(false);
        bus.setMotivoMantencion(motivo);

    }

    /**
     * Método que entrega la lista de camiones con los parametros de busqueda solicidados.7
     * @param todos - Piden todos los datos.
     * @param mantencion - Se requiere el camion con mantención al día.
     * @param tipo - Que tipo de carga transporta.
     * @param menorkm - Se requiere que se muestren solo los que tienen menor kilometraje
     * @return TreeSet con los datos separados.
     */
    public TreeSet<Camion> sublistasCamion(boolean todos, boolean mantencion, TipoCarga tipo, boolean menorkm){
        TreeSet<Camion> busqueda = new TreeSet<>(),
                aux1 = new TreeSet<>();
        busqueda.addAll(camiones);
        if (todos) {
            return busqueda;
        }
        for (Camion camion : busqueda) {
            if (camion.isMantencion() == mantencion) {
                aux1.add(camion);
            }
        }
        busqueda.clear();
        busqueda.addAll(aux1);
        aux1.clear();

        for (Camion camion : busqueda) {
            if (camion.getCarga().equals(tipo.getTipo())) {
                aux1.add(camion);
            }
        }
        busqueda.clear();
        busqueda.addAll(aux1);
        aux1.clear();

        if (!mantencion && menorkm) {
            for (Camion camion : busqueda) {
                if (camion.getKmActual() < 60000) {
                    aux1.add(camion);
                }
            }
            busqueda.clear();
            busqueda.addAll(aux1);
        }

        return busqueda;
    }

    /**
     * Método que entrega la lista de buses con los parametros de busqueda solicidados.
     * @param todos - Piden todos los datos.
     * @param mantencion - Se requiere el bus con mantención al día.
     * @param tipo - Que tipo de carga transporta.
     * @param piso2 - Se necesitan buses de 2 pisos.
     * @param menorkm - Se requiere que se muestren solo los que tienen menor kilometraje
     * @return TreeSet con los datos separados.
     */
    public TreeSet<Bus> sublistasBus(boolean todos, boolean mantencion, TipoCarga tipo, boolean piso2, boolean menorkm){
        TreeSet<Bus> busqueda = new TreeSet<>(),
                aux1 = new TreeSet<>();
        busqueda.addAll(buses);
        if (todos) {
            return busqueda;
        }

        for (Bus b:busqueda) {
            if (b.isMantencion() == mantencion) {
                aux1.add(b);
            }
        }
        busqueda.clear();
        busqueda.addAll(aux1);
        aux1.clear();

        for (Bus b:busqueda) {
            if (b.getCarga().equalsIgnoreCase(tipo.getTipo())) {
                aux1.add(b);
            }
        }
        busqueda.clear();
        busqueda.addAll(aux1);
        aux1.clear();

        for (Bus b:busqueda) {
            if (b.isPiso2() == piso2) {
                aux1.add(b);
            }
        }
        busqueda.clear();
        busqueda.addAll(aux1);
        aux1.clear();

        if(!mantencion && menorkm) {
            for (Bus b:busqueda) {
                if (b.getKmActual() < 60000) {
                    aux1.add(b);
                }
            }
            busqueda.clear();
            busqueda.addAll(aux1);

        }
        return busqueda;
    }

}
